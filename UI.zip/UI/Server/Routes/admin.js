// const express = require('express');
// const dotenv = require('dotenv');
// const mysql = require('mysql2');
// appForAdmin = require('./admin.js');

// var connection = mysql.createConnection({
//     HOST    :   process.env.HOST,
//     USER    :   process.env.USER,
//     PASSWORD:   process.env.PASSWORD,
//     DATABASE:   process.env.DATABASE
// });


